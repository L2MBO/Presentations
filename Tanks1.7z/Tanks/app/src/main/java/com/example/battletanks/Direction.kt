package com.example.battletanks

enum class Direction {
    UP,
    DOWN,
    RIGHT,
    LEFT,
}